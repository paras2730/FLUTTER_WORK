# Welcome page, Login Page and Sign up page - Flutter UI

## [Watch it on YouTube](https://youtu.be/ExKYjqgswJg)

**Packages we are using:**

- flutter_svg: [link](https://pub.dev/packages/flutter_svg)

We design 3 screens first one is a welcome screen like then user open your app it shows then users have two options, if he has an account then press the login button and it just shifts him to the login screen or if he or she don't have an account then press signup button its transfers to the signup screen.

### Auth UI

![App UI](/UI.png)
